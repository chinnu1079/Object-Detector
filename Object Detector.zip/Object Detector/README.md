# Object-Detection
Object Detection using Jupyter Notebook, OpenCV and Matplotlib
